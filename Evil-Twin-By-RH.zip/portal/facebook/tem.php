<?php
    date_default_timezone_set('Asia/Yangon');
    $time = date("Y/m/d h:i a");
    echo $time; 
?>
